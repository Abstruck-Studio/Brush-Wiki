package com.example.mdk;

import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import org.abstruck.brush.api.BrushEvents;
import org.abstruck.brush.api.BrushModInitializer;
import org.abstruck.brush.api.BrushRegistry;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Brush MDK 示例 mod 主入口 —— 把本文件改造成你自己的 mod 吧。
 *
 * <p><b>入口契约</b>：{@code brush.mod.json} 的 {@code entrypoints.main} 所列类须为
 * <b>public 具体类 + public 无参构造器 + 实现 {@link BrushModInitializer}</b>。
 * 加载器在游戏代码运行之前构造其实例、随即调用 {@link #onInitialize()}；
 * 此时游戏<b>尚未就绪</b>（这是"注册期"），因此只应注册监听器，不要直接碰注册表 / 世界 / 渲染。
 *
 * <p><b>内容注册（物品 / 方块 / …）只能在 {@link BrushEvents#CONTENT_REGISTRATION} 的监听器体内做</b>
 * —— 那是 vanilla 注册表唯一的合法注册窗口（更早触碰会抛 "Not bootstrapped"，更晚会抛
 * "Registry is already frozen"）。本示例注册一个物品 {@code mdkexample:wand}。
 *
 * <p><b>只依赖 {@code org.abstruck.brush.api.**}</b>：编译面就是 MDK 里的作者契约 jar
 * （{@code ../Brush/build/libs/brush-api-contract.jar}）。需要平台特定行为时用
 * {@code BrushExpectPlatform}（契约面内），需要更底层能力时才考虑 mixin。
 *
 * <p><b>三运行时同一份字节码</b>：本类零宿主依赖，S1（纯 Brush）/ S2（Fabric 宿主）/
 * S3（NeoForge 宿主）行为一致 —— 这正是 Brush "一个 jar 跑三处"的卖点。
 */
public final class ExampleMod implements BrushModInitializer {

    private static final Logger LOGGER = LogManager.getLogger("mdkexample");

    /** 你的 mod id（须与 {@code brush.mod.json} 的 {@code id} 一致，也用作资源命名空间）。 */
    public static final String MOD_ID = "mdkexample";

    /** 示例物品 id：{@code mdkexample:wand}。 */
    public static final Identifier WAND = Identifier.fromNamespaceAndPath(MOD_ID, "wand");

    @Override
    public void onInitialize() {
        LOGGER.info("[mdkexample] onInitialize -- 游戏尚未就绪，这里只注册监听器");

        // 内容注册：窗口到达时才真正执行（监听器体内）
        BrushEvents.CONTENT_REGISTRATION.register(event ->
                BrushRegistry.registerItem(WAND, new Item.Properties()));

        // 想再加生命周期行为？例如每帧 tick：
        // BrushEvents.CLIENT_TICK.register(event -> { ... });   // 热路径：注意节流（勿每帧打日志）
        // 其它可用事件见 org.abstruck.brush.api.BrushEvents 的字段表。
    }
}
